# Evidence for the Bayesian methods and late toxicity review

This archive accompanies 2026_11_12_bayesian_methods_and_late_toxicity_review.md. The main review is the implementation plan. These are its supporting records.

## Contents and scope

- methods/: actual application-engine sensitivity script and aggregate output tables, independent Python calculation, input/output hashes, and statistical review notes.
- code/: hashes of inspected source files and code/navigation/deployment review notes. The isolated deployment-preflight suite passed 13 test blocks and 47 expectations. The broader attempted suite did not complete, and is not certified.
- clinical/: primary-source inventory, exact local proof paths, PDF hashes, extraction checks and failed Beitler PDF acquisition records. This is not a complete extracted late-toxicity dataset.
- audits/: scoped pipeline configuration/results, constant/evidence/simulation/reader/gate outputs and final deliverable checks. No claim is made that the project's full release gate passed.

## Reproducing the decision sensitivity

Use R 4.5.1 and the library path recorded in methods/verify_app_engine.R. Set root to the reviewed v45 application directory and out to an existing scratch directory. Run the R script. It calls the actual load_early_fit, fitted_early_params and v4_regimens functions. Compare every row with decision_sensitivity_R_summary.csv and inspect verification_provenance.json before treating any difference as an error. A later application revision may legitimately change the results.

The Python script provides an independent implementation check, not a replacement source of truth for the deployed calculator. Its constants and source assumptions are recorded in the review notes.

## Interpreting the audit logs

The strict constant registry passed for its registered/excluded scope. The evidence ledger is incomplete for current about.md, with 767 findings, not 767 demonstrated wrong scientific values. The simulation registry schema passed; formal run tracing was missing and the secondary literal scan was not clean. The reader executable assumes a manuscript structure and had empty method inventories, so its structural findings must not be treated as requirements to put an Abstract/Results/Discussion into an application dialog. The active tree has no local routing manifest. The scoped pipeline file/row-count checks passed with three timestamp advisories, which need identity/rebuild reconciliation before a release.

The work was performed in scratch copies or read-only checks. No app implementation, model refit, commit, push, or deployment occurred. Final review corrections resolved the inline-math delimiters, HTML rendering wrapper, per-arm penalty scope, delivery-time ordering, covariate definition, four-arm labels, and explicit missing-PDF note. Domain notes may show those issues as findings from the earlier draft; deliverable_qa.json records their resolution.

Licensed source PDFs are not redistributed in this archive. Seven already-held PDFs were copied into the project's References/late_toxicity_review_2026_11_12 directory. Beitler 2014 remains a primary-full-text proof gap for local PDF storage: PMC returned HTML and Europe PMC returned HTTP 403.
