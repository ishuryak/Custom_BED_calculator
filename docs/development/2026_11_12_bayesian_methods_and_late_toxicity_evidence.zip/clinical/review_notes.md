# Clinical evidence review notes

Internal working notes, 2026-11-12. Scope: read-only late-toxicity clinical feasibility, radiation oncology, and radiation epidemiology review. No project files changed. Full bibliographic metadata, verified URLs, proof PDF paths, and page locators are in late_reference_inventory.json.

## Prior findings

Verdict: a new late-outcome extraction is feasible, but the proposed combined endpoint and observation model need revision before fitting. Existing acute mucositis and tumor-control outcomes cannot be reused as late events. The raw early table has 68 records, 66 distinct arm identifiers and 29 families. The tumor table has 45 control-outcome records. These are not counts of late-toxicity observations.

The original plan's proposed primary grade 3+ late mucosal OR any-site outcome at 2–5 years combines different tissues, grades, horizons, populations, and estimators. Preserve tissue/composite definition, grading system/version, event definition, time origin, horizon, analysis population, recurrence/salvage handling, death handling, and denominator or summary-estimate uncertainty. Endpoint compatibility precedes likelihood selection. An intercept cannot turn fibrosis, mucosal atrophy, dysphagia, and any-site maximum into one calibrated endpoint.

Not all late outcomes are counted only among survivors. Fu1995 uses cumulative incidence with death as competing event. Horiot1992 selects patients with locoregional control. Mortensen2012 uses a late-evaluable subset and as-treated grouping. RTOG9003 reports both worst-ever events and visit-specific prevalence. A randomized denominator is not intrinsically invalid for a properly observed fixed-horizon competing-risk probability. Death-censored Kaplan–Meier net risk, cumulative incidence, prevalence, and worst grade are different targets. An effective sample size cannot reconcile them. A percentage without grade-specific uncertainty or a valid denominator cannot become exact events by multiplication and rounding.

Stuschke1999 late estimates depend on EORTC22791 alone, grade 2+ late reactions and assumed dose-response slope. The abstract's 4.0Gy (3.3–5.0) at fixed gamma50=5 is an exact reported conditional result, not a universal late prior. CHART repair estimates condition on external fractionation sensitivity and dose-response slope and cannot identify multiple repair components from a single interfraction interval. If the underlying trials enter a likelihood, reusing these derived estimates as independent informative priors leaks the same outcome evidence into the model twice.

Incomplete repair requires explicit schedule handling, but omitted-repair bias in fitted alpha/beta is not universally upward. Slope/intercepts/heterogeneity can absorb misspecification. RTOG83-13 intervals were not randomized, and protocol dose arms changed during accrual. Within-trial equal fraction number and dose identify a pure treatment-time check only if repair exposure and other treatment components are comparable. A fixed-d dose-escalation contrast alone does not separate fractionation sensitivity from a free risk slope.

Prescription is not automatically late-tissue dose. EORTC22791 reports upper-neck subcutaneous hotspots74–77Gy CF and85–88Gy HF versus prescriptions70/80.5Gy. Field reductions, boosts and modern tissue-dose distributions require explicit exposure definitions. Missing tissue dose should be labeled as a prescription-dose surrogate; do not invent precise random-error distributions. Errors may be shared and correlated with treatment schedule.

Consequential injury is plausible but aggregate acute-to-late association does not establish mediation. Denham1999 selected191of274 without persistent cancer and with adequate survival/follow-up. Acute reactions had healed; the association may include susceptibility. Acute observed severity is a post-treatment variable. Planned early BED is an exploratory structural predictor requiring uncertainty propagation and collinearity checks. HYPNO's four versus five planned cisplatin cycles and different delivered doses mean a shared binary chemotherapy label does not cancel all treatment differences. Adjustment for delivered therapy may alter the randomized estimand.

Source surprises requiring adjudication: Horiot1992 TableXI has22 HF fibrosis events while Figure2 has23. Horiot1997 Figures5and6 appear to repeat curves and totals for different outcomes; this was visually inspected. Beitler2014 defines late beyond180days from treatment start, unlike Fu2000's90days. These reports belong to one family. Beitler's local PDF was absent in an author/PMID search; PMC primary full text was read. Parent is handling acquisition.

Not checked: a complete systematic late extraction, individual-patient reanalysis, dose-volume reconstruction, full clinical transport validation, or actual late-model fitting. An insufficient-information result remains an acceptable feasibility outcome.

## Consolidated draft check

Checked Sections4and6 and all8listed references. Source metadata agree with the verified bibliography. Beitler's final journal title uses RTOG9003, as PubMed24613816 explicitly records; the PMC author-manuscript heading uses RTOG90-03. The draft correctly uses the final journal title. DOI10.1016/j.ijrobp.2013.12.027.

All numeric table cells in Section4.1 were checked, not sampled:
- Fu2000: grade3+4 mucosal sums4+7=11,9+10=19,7+12=19,15+14=29; denominators254,253,261,261. Late>90days from start.
- Beitler2014: five-year prevalence6/71,8/84,12/70,13/80. Worst grade3–5 sums44+22+2=68,40+24+1=65,45+22+2=69,61+23+1=85; denominators234,232,239,232. Late>180days from start.
- Mortensen2012: peak severe fibrosis70/632and83/617; five-year actuarial fibrosis13.0%and16.7%.
- Stuschke1999: conditional late alpha/beta4.0Gy, interval3.3–5.0Gy, fixed gamma50=5, grade2+.
- Remaining two rows have no clinical effect-size numbers; Fu1995 competing-death interpretation and Bentzen1999 conditional-repair description confirmed against full PDFs.
- Section4.1 raw68rows verified against CSV; primary22families/51arms/6042patients agrees with current early_fit_in_brief.md. The96of120PDF screening count is attributed to the original plan rather than presented as an independently rerun search.

Section6 numeric/equation check: independently summed every cross-fraction repair term for35fractions,2Gy each, seven Monday–Friday weeks, half-time4hours, alpha/beta3Gy. Excess absolute BED=1.1805450578093952Gy, consistent with1.18Gy. Geometric center of1and10Gy is3.1622776601683795Gy. Median3with symmetric logarithmic endpoints1and9Gy is correct. Repair quadratic form has unitsGy squared; BED addsGy. Limits and dimensionless logit predictor are correct when indices are chronologically ordered and half-time is positive.

Material clarifications to relay:
1. Explicitly require sorted delivery times t_j>=t_i for i<j (or use absolute differences) and h>0. Otherwise the written kernel and claim of a tested common evaluator leave invalid time ordering undefined.
2. Section6.2 wording incorrectly includes the co-treatment covariate z among quantities on the log-odds scale. Define z as the coded planned-treatment contrast; gamma*z contributes to log odds. Define units/coding of z.
3. Section4.1 should state four-arm order once: standard fractionation, hyperfractionation, accelerated split course, accelerated concomitant boost. The numbers are correct but currently unlabeled within each cell.
4. Reference2 should explicitly state missing local PDF until acquisition succeeds, rather than hiding the status only in evidence notes. No title correction is necessary.

Draft SHA-256 at checking: 2c54ce235fc8d8484cc2f9d888ad32a664717efa18fcdf4814553b4f9b38f1e2

## Source-by-source archived findings

1. **Stuschke_1999_review**. Late parameter estimate uses EORTC 22791 alone, grade 2+ fibrosis/any late reaction, conditional on selected dose-response slope. Not an independent prior if that trial enters the likelihood. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\pdfs\Stuschke_1999_review_10435801.pdf; pages 5–6. https://pubmed.ncbi.nlm.nih.gov/10435801/

2. **Bentzen_SM_1999_10660202**. Five-year inverse-Kaplan–Meier morbidity with standard errors. Repair times are conditional on external α/β and slope assumptions; one interval cannot identify repair kinetics. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Bentzen_SM_1999_10660202_Repair_halftimes_estimated_from_observations_of_treatment_related_morb.pdf; pages 4–7. https://pubmed.ncbi.nlm.nih.gov/10660202/

3. **Fu_KK_2000_10924966**. Table 4 worst late mucosal grade 3+ counts: 11/254, 19/253, 19/261, 29/261. Table 5 any-site grade 3+ at 24 months: 7/111,17/135,9/116,10/128. Different endpoints and estimands; late defined >90 days from start. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Fu_KK_2000_10924966_A_Radiation_Therapy_Oncology_Group_RTOG_phase_III_randomized_study_to.pdf; pages 8–9. https://pubmed.ncbi.nlm.nih.gov/10924966/

4. **Beitler_2014_24613816**. No local PDF found by author/PMID search. PMC full text read. Five-year any-site grade 3–5 prevalence: 6/71,8/84,12/70,13/80. Worst late grade 3–5 counts: 68/234,65/232,69/239,85/232. Late >180 days from start. Same RTOG 9003 family as Fu2000, not independent. Proof: Local PDF acquisition pending; PMC full text read; pages PMC Methods and Tables 3–4. https://pubmed.ncbi.nlm.nih.gov/24613816/

5. **Mortensen_HR_2012_22398313**. Late subset ≥6 months follow-up, as-treated analysis. Table 2 peak severe fibrosis 70/632 vs83/617; mucosal atrophy43/626 vs43/614. Five-year actuarial fibrosis13.0% vs16.7%, atrophy6.4% vs8.3%. Late endpoints partly reversible; estimator distinctions matter. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Mortensen_HR_2012_22398313_Prevalence_and_peak_incidence_of_acute_and_late_normal_tissue_morbidit.pdf; pages 2,4. https://pubmed.ncbi.nlm.nih.gov/22398313/

6. **Fu_KK_1995_7790242**. 399 late-evaluable patients; dose groups n59,119,98,123; Table3 grade3+ worst late counts12,19,20,15. Cumulative-incidence estimator explicitly accounts for competing death. Actual dose/interval groups are not clean randomized contrasts. DOI final character is capital I. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Fu_KK_1995_7790242_Late_effects_of_hyperfractionated_radiotherapy_for_advanced_head_and_n.pdf; pages 1–5,8. https://pubmed.ncbi.nlm.nih.gov/7790242/

7. **Denham_JW_1999_10577701**. Selected 191/274 without persistent cancer and with ≥12-month survival/follow-up. RTOG grade3 mucosa describes atrophy/dryness/telangiectasia; ulceration is grade4. Acute-duration association does not establish causal mediation; acute reactions healed. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Denham_JW_1999_10577701_Do_acute_mucosal_reactions_lead_to_consequential_late_reactions_in_pat.pdf; pages 2–4,7. https://pubmed.ncbi.nlm.nih.gov/10577701/

8. **Horiot_JC_1992_1480768**. Selected locoregional-control patients118/135; TableXI fibrosis grade2+3 events21/22 while Figure2 reports21/23. Source conflict requires adjudication. Upper-neck subcutaneous dose hotspots74–77Gy CF,85–88Gy HF exceed70/80.5Gy prescriptions. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Horiot_JC_1992_1480768_Hyperfractionation_versus_conventional_fractionation_in_oropharyngeal.pdf; pages 6. https://pubmed.ncbi.nlm.nih.gov/1480768/

9. **Cox_JD_1991_2045293**. Intervals were not randomized; longer intervals encouraged during accrual while dose arms changed. Overlaps Fu1995. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Cox_JD_1991_2045293_ASTRO_plenary_interfraction_interval_is_a_major_determinant_of_late_ef.pdf; pages 2–3. https://pubmed.ncbi.nlm.nih.gov/2045293/

10. **Horiot_JC_1997_9288839**. Three-year freedom from grade3/4 late toxicity85%(95%CI78–92) vs63%(54–72). Text fibrosis4vs29, mucosa9vs25. Figures5and6 appear to repeat identical curves/counts despite different endpoints; visually checked, requires adjudication. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Horiot_JC_1997_9288839_Accelerated_fractionation_AF_compared_to_conventional_fractionation_CF.pdf; pages 7. https://pubmed.ncbi.nlm.nih.gov/9288839/

11. **Dische_S_1997_9288840**. Late >6 months from start, Dische morbidity dictionary. Table5 event totals are not fixed-horizon binomial risks. Same CHART family as Bentzen1999 and Saunders2010. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Dische_S_1997_9288840_A_randomised_multicentre_trial_of_CHART_versus_conventional_radiothera.pdf; pages 7,10,12. https://pubmed.ncbi.nlm.nih.gov/9288840/

12. **Saunders_MI_2010_20394851**. Ten-year estimates with standard errors, outside proposed2–5year horizon. Paper explicitly warns severe Dische grading differs from RTOG/EORTC severe. CHART overlap. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Saunders_MI_2010_20394851_Mature_results_of_a_randomized_trial_of_accelerated_hyperfractionated.pdf; pages 4. https://pubmed.ncbi.nlm.nih.gov/20394851/

13. **Poulsen_MG_2001_11439206**. Table5 five-year actuarial grade3+ mucosal toxicity29%CF vs25%ART without grade3 endpoint SE/CI or endpoint denominator. Figure4 grade2+ curves and risk tables cannot be used as grade3 uncertainty. Do not manufacture counts from initial171/172. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Poulsen_MG_2001_11439206_A_randomised_trial_of_accelerated_and_conventional_radiotherapy_for_st.pdf; pages 3,7. https://pubmed.ncbi.nlm.nih.gov/11439206/

14. **Bernier_J_1998_9683360**. Secondary EORTC22791 correlations; overlapping cohort, weak imprecise early-late associations. Recurrence counts are not toxicity counts. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_refit_trials\eric_2026_10_22\Part 3\Bernier_J_1998_9683360_Tumor_response_mucosal_reactions_and_late_effects_after_conventional_a.pdf; pages 4–6. https://pubmed.ncbi.nlm.nih.gov/9683360/

15. **Bentzen_2026_HYPNO**. Three-year Kaplan–Meier any late grade3+18.8±2.4%HFX vs20.2±2.4%NFX; late-evaluable390/391. Late≥90days from end. Planned weekly cisplatin4vs5cycles, delivered121vs149mg/m². Not a pure radiation-fractionation contrast. Proof: C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\References_OAR\Bentzen_2026_HYPNO.pdf; pages 5–6,8,10. https://pubmed.ncbi.nlm.nih.gov/41711624/

