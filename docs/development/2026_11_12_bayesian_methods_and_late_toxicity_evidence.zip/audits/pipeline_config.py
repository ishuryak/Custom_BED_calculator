# Scoped read-only runtime/export audit, not full release certification.
PROJECT_DIR = 'C:\\Users\\Igor\\Desktop\\Office\\HNSCC_BED_calculator\\Custom_BED_calculator_v45'
SCRIPTS = {'app_runtime': {'path': 'app.R', 'language': 'R', 'inputs': ['R/bed_models.R', 'R/schedule.R', 'R/uncertainty.R', 'R/v4_home.R', 'draws/draws_manifest.json', 'draws/early_fit_manifest.json', 'refit_in_brief.md', 'early_fit_in_brief.md'], 'outputs': []}, 'early_export': {'path': 'tools/early_tox/export_fit_for_app.py', 'language': 'python', 'inputs': ['docs/development/2026_11_10_early_toxicity/step5_review/overdispersed/U02/manifest.json', 'docs/development/2026_11_10_early_toxicity/step5_review/overdispersed/U02/diagnostics.json', 'docs/development/2026_11_10_early_toxicity/step5_review/overdispersed/U02/draws.csv.gz'], 'outputs': ['draws/early_fit_manifest.json', 'draws/early_fit_draws.csv', 'draws/early_fit_trials.csv']}}
EXPECTED_SAMPLE_SIZES = {'data/refit_trials_2026_10_25c_main.csv': 45, 'data/early_tox/outcomes.csv': 68, 'draws/early_fit_draws.csv': 4000, 'draws/early_fit_trials.csv': 66}
CONSISTENT_PARAMS = {}
PARAM_PATTERNS = {}
BAD_PATTERNS = {}
GOOD_PATTERNS = {}
CHECK_GIT_STATUS = False
CHECK_NOTEBOOK_EXECUTION = False
RELEASE_MODE = False
