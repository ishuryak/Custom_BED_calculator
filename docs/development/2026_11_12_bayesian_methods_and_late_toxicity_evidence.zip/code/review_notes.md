# Code and active-model review, 2026-11-12

Scope: read-only review of Custom_BED_calculator_v45, Issue 1 of the methods-page and late-toxicity plan. The parent agent handles clinical evidence, methods, and live UI inspection. No project source files were modified.

## Findings delivered to the parent

1. The active app DD model is calibrated conditionally on DI, not the free DD model. The Nov12 audit inspected free dd.stan and proposed testing its C prior against the new page. The active model inherits alpha, alpha/beta and g from each DI draw, solves C/alpha at 35 x 2 Gy in 47 inclusive days, and estimates lambda_dd, trial baselines and arm dispersion conditionally. Source: fit/fit_dd_calibrated.py:1-24; fit/stan/dd_cal.stan:58-76; draws/draws_manifest.json:4,18-22. This is a modular/cut construction, not independent fits or unrestricted joint fitting.
2. The audit's categorical hierarchy objection and proposed banned-word test are wrong. Tumor baselines have independent fixed-scale priors, but arm effects have an estimated population scale. Explain the hierarchy rather than ban a word. Source: fit/stan/di.stan:27-38,52-63; tools/early_tox/step5_model.stan:58-83.
3. Navigation uses full page titles, while menu controls use slugs. The audit's section == fitted test requires an explicit panel value that does not yet exist. Retarget the three tumor links, new Details button, menu entry and early_how to a single destination with relevant section anchors. Source: app.R:409-426,438-443,465-467,547,1552-1561,1819-1835.
4. Deployment required assets are in tools/deploy_preflight.R::check_bundle, not tools/deploy.R. docs, fit and tools are excluded from deployment. Root how_fitted.md must not read model sources at runtime. Existing empty-file checks cover SERVED_ASSETS, so adding only a required filename will not reject empty root markdown. Add missing and empty tests.
5. Render math using the actual app.R:1548 idiom with HTML(markdown::mark(..., options='+latex_math')) inside withMathJax. Existing equation/table CSS is scoped to #about (app.R:503-504).
6. Include tests/testthat/test_v45_review.R:179-190 in the menu ripple. It fixes exact six-menu membership. Existing expect_silent(click) assertions do not verify the destination. Browser checks should prove navigation, focused/visible heading, back behavior, preserved state, equation rendering and mobile layout.
7. The early dialog already explains Bayesian methods and limitations. Improve unified discovery and the initial tumor explanation. Do not suggest Bayesian documentation is absent. Convergence and simulation-based calibration do not validate clinical outcome assumptions. Tumor likelihood uses rounded N times reported rate, often Kaplan-Meier/CIF, as an approximation.

## Active specification verified against complete model files

DI likelihood is binomial with p=exp(-exp(eta)); eta includes trial-centered BED and time, repopulation, trial intercept and arm effect. DI priors: alpha lognormal(log .2,1), lambda lognormal(log .1,1.5), Tk normal(28,10) truncated 0-60 days, alpha/beta lognormal(log 10,.354), g uniform .0046-.021 per day, trial c normal(0,3), arm SD half-normal .5, z standard normal. See di.stan:27-38,44-63 and fit_refit.py:35-51,119.

Calibrated DD priors: lambda_dd lognormal(log .5,1.5), c normal(0,3), arm SD half-normal .5, z standard normal. The log-density penalty is -sum(exp((7-onset_i)/1 day)); it is not a hard day-7 bound. Alpha, alpha/beta and g are conditional DI values and C/alpha is solved, not freely assigned the free-DD C prior. See fit_dd_calibrated.py:37-45 and dd_cal.stan:58-76.

Early likelihood is binomial-logistic with a family baseline, grading-group adjustment, kappa times within-family BED contrast, coarse chemotherapy coefficient and arm effect. Primary exposure uses D+Q/ab-r*max(0,T_elapsed-7), repair half-time 3.2 hours and exact hinge. Priors: m0 normal(0,2.5), tau0 half-normal 1, z standard normal, grading offset normal(0,1), Lstar=10*kappa half-normal 1, ab lognormal(log10,.354), r lognormal(log.8,.5), gamma normal(0,1), sigma_arm half-normal .5, zarm standard normal. See step5_model.stan:51-83; step5_fit.py:119-120; early_fit_manifest.json:13-18.

DI retained identity: four chains, 1500 warmup plus 2000 retained per chain, adapt_delta .99 and max_treedepth 12. Conditional DD: 1000 outer DI draws, initial four chains of 600 warmup plus 250 retained per chain, three maximum attempts, subsequent documented repairs. Early U02: four chains, 1000 warmup plus 1000 retained per chain, adapt_delta .95. The early gate records tree-depth hits but omits them from its pass condition, unlike the tumor gate. Do not claim an identical gate. Sources: fit_refit.py:37,137; fit_dd_calibrated.py:42-45,155-168; step5_fit.py:275-276,330-357.

Retained tumor identities were read from sibling Custom_BED_calculator_v3/fit/output_refit_2026_10_25c_main/di_primary/identity.json and dd_calibrated_onset7_n1000/identity.json. Identities are 2c828af600ee3d7bafd971a00495d5ecbc9e8a47e56136783572995fbdb1a65e and 2a1ab8937a623e1d962e997fa2530c84a22a70c0f2e4f442299be968defa813d. Their Stan hashes match current reviewed model files. Runtime prior values and retained identities, not current defaults alone, should drive historical methods metadata.

## Checks and state

- No project files changed. Source hashes are in source_hashes.json beside this note.
- Worktree HEAD, read through its .git/worktree reference, is 52f0d3b1b672524ca245c893dffcf186486a6950. .suite_passed and deployed_revision.txt both say faf68173fc53d2cad467c6c7133277191c71ea15, stale relative to current source. The separate v4 branch ref is ba9fe517ba8ac92aa18fc2af3baf3865de4a4fd6. Git status could not be certified due sandbox access.
- Scratch-only deployment preflight suite: 13 test blocks, 47 expectations, zero failures/errors. The broader combined app-suite attempt was stopped without a result; no full-suite pass is claimed.
- Runtime: C:/Program Files/R/R-4.5.1/bin/Rscript.exe. Release library: C:/Users/Igor/AppData/Local/R/cache/R/HNSCC_BED_calculator/library-2026-10-15-R4.5.1. Tests ran from scratch test_checkout with this library, not in the project.
- Export hash/dimensions and dataset count checks: tumor 45 arms/strata, 21 fitting units, 19 trials, 8279 patients. Early primary 51 arms, 22 families, 6042 evaluable patients. Raw outcome row counts are different denominators.
- Tumor export has 4000 paired rows with 1000 distinct DI draws repeated four times. Early export has 4000 joint draws.
- DI daily BED-loss median independently calculated .6314015174 Gy/day; drawwise EQD2 median .5303866746 Gy/day. Their 95% intervals are [.2133142324,1.1879911967] and [.1820856283,.9928938390], respectively. Background EQD2 median .2323075212 with interval [.09582420275,.3987604042]. Do not convert independent marginal summaries instead of draws.
- Main Refit support uses either valid tumor model; Uncertainty has a configurable criterion and defaults to both. Source: R/v4_home.R:83-88; R/mod_uncertainty.R:17-30. Neither is a clinical probability. Tumor/toxicity independent pairing is an assumption.
- No fit or raw-chain diagnostics rerun. Parent handles live UI and global evidence/audit runners.

## Consolidated draft verification

Read outputs/2026_11_12_bayesian_methods_and_late_toxicity_review.md sections 2-3 and 8-9. Re-read full di.stan, dd_cal.stan, step5_model.stan and active step5 prior assignments. All 18 entries of the Section 3.4 prior/fixed-settings table agree with active artifacts, including lognormal widths, truncation, uniform bounds, SD priors, early per-10-Gy slope scaling and calibrated-DD penalty. The numerical sampler settings, draw grouping and isolated-test counts agree with retained artifacts and this review.

One material correction: M4's illustrative rendering expression omits HTML(). Use the actual app idiom withMathJax(HTML(markdown::mark(text=txt, options='+latex_math'))), otherwise the generated HTML can be escaped rather than rendered as markdown. app.R:1548 contains the established correct form.

One implementation precision addition: Section 3.4's calibrated-DD penalty describes location and scale but does not explicitly say it is applied to every fitted arm. Add that phrase, or record the exact negative sum in metadata. A single-anchor penalty is a different prior because the existing code sums over all fitted-arm onsets (dd_cal.stan:75).

No additional material contradiction was found in the scoped draft sections. This is not a certification of other agents' numerical or clinical sections.
