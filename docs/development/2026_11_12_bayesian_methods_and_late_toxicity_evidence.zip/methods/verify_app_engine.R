.libPaths(c('C:/Users/Igor/AppData/Local/R/cache/R/HNSCC_BED_calculator/library-2026-10-15-R4.5.1', .Library))
stopifnot(requireNamespace('jsonlite', quietly=TRUE), requireNamespace('digest', quietly=TRUE))
root <- 'C:/Users/Igor/Desktop/Office/HNSCC_BED_calculator/Custom_BED_calculator_v45'
out <- 'C:/Users/Igor/Documents/Codex/2026-11-10/for-this-project-c-users-igor/work/review_2026_11_12/methods'
for (f in c('bed_models.R','schedule.R','uncertainty.R','v4_home.R')) source(file.path(root,'R',f))
DRAWS_DIR <- file.path(root,'draws')
rp <- refit_profile(DRAWS_DIR)
stopifnot(isTRUE(rp$ok))
p0 <- modifyList(default_params(),startup_profile(rp)$values)
ef <- load_early_fit(DRAWS_DIR)
stopifnot(isTRUE(ef$ok))
ps <- list(fowler=p0, fitted=fitted_early_params(p0,ef))
alphas <- c(1,1.5,1.58,1.59,1.61,1.62,2,2.5,3,4,5)
summary <- list(); detail <- list()
for (mode in names(ps)) for (ab in alphas) {
  p <- modifyList(ps[[mode]],list(ab_l=ab))
  got <- v4_regimens(p)
  rr <- got$rows
  summary[[length(summary)+1]] <- data.frame(mode=mode,late_ab=ab,dose_count=nrow(rr),fraction_rows=length(unique(rr$m)),fraction_counts=paste(sort(unique(rr$m)),collapse=';'))
  if (nrow(rr)) detail[[length(detail)+1]] <- data.frame(mode=mode,late_ab=ab,rr)
}
s <- do.call(rbind,summary);d <- do.call(rbind,detail)
write.csv(s,file.path(out,'decision_sensitivity_R_summary.csv'),row.names=FALSE)
write.csv(d,file.path(out,'decision_sensitivity_R_app_rows.csv'),row.names=FALSE)
stopifnot(s$dose_count[s$mode=='fowler' & s$late_ab==3]==69,
          s$dose_count[s$mode=='fitted' & s$late_ab==3]==9,
          all(s$dose_count[s$mode=='fitted']==9))
print(s)
cat('Research point values loaded from validated current manifest:\n')
print(ef$point)
cat('Manifest SHA256:',ef$package_sha256,'\nDraws SHA256:',ef$draws_sha256,'\n')
cat('Libraries:',paste(.libPaths(),collapse=' | '),'\n')
print(sessionInfo())
