# Statistical methods review notes, 2026-11-12

Internal evidence archive. Review-only work. No project application, fitting, data, or plan files were modified. Scratch calculations and these notes were written in the Codex workspace.

## Scope and source identity

Project: `C:/Users/Igor/Desktop/Office/HNSCC_BED_calculator/Custom_BED_calculator_v45`.

Primary source reviewed: `docs/development/2026_11_12_plan_audit_fitting_page_and_late_refit.md`, SHA-256 `ba3758a4ede3a3732129212672b1504dffdc16da0c2ceeb5e27ebd3448d57187`.

Final consolidated draft reviewed: `outputs/2026_11_12_bayesian_methods_and_late_toxicity_review.md`, SHA-256 at this check `2c54ce235fc8d8484cc2f9d888ad32a664717efa18fcdf4814553b4f9b38f1e2`.

Other inspected sources included the application's schedule, BED, uncertainty, and home-list functions, current early-fit manifests and parameter loader, and early-toxicity extraction/identification infrastructure. Exact source and output hashes are recorded in `verification_provenance.json` beside this file. The local deployment marker contains `faf68173fc53d2cad467c6c7133277191c71ea15`. This alone does not establish the live revision. The consolidated report correctly distinguishes the local marker, reviewed worktree, and observed live behavior.

## Prior findings on the original plan

1. **Decision sensitivity was incompletely characterized (original plan lines 210–241).** The phrase “about 2 Gy or below” described the Fowler model only and did not locate the actual candidate-list threshold. Recalculation with the real application engine gives the first current Fowler candidate loss below 1.6156626506024 Gy, for 29 fractions of 2.30 Gy. At late α/β of 3 Gy there are 69 dose/fraction combinations across 18 fraction counts. The validated research early model gives nine combinations across five fraction counts. Every one of those nine has both total dose below 70 Gy and complete-repair quadratic dose sum below 140 Gy², so its late BED is below the reference for every positive late α/β. The original plan's `early_cal` interpretation was incorrect: that argument concerns the calendar, not a separate statistical relative-calibration correction.

2. **The endpoint and denominator proposal conflated distinct estimands (lines 268–284, 350–351).** Cumulative incidence, Kaplan–Meier net risk, survivor-conditional prevalence, and worst recorded grade over variable follow-up are not interchangeable observations. “Mucosal or any-site at 2–5 years” does not define one outcome. A randomized denominator is valid for a cumulative incidence target if follow-up to the event, death, or horizon is adequate. Survivor-conditional prevalence is a different target and is generally not an unconditional randomized treatment effect. Select tissue, grade, observation window, estimator, and eligible population before pooling.

3. **An effective-sample-size rule should not manufacture exact counts (lines 275–280).** Genuine compatible counts support a binomial likelihood. Compatible fixed-horizon estimates and their uncertainty can support an explicitly approximate summary likelihood, for example on a transformed probability scale. Event histories can support an appropriate survival or competing-risk model. Missing uncertainty is not repaired by guessing an effective denominator and rounding an event count. Repeated horizons, shared controls, overlapping reports, and multiple outcomes require dependence handling or prespecified selection.

4. **The proposed omitted-repair bias direction and test were too rigid (lines 243–266).** Upward bias in α/β is plausible in some designs, but its direction depends on the contrasts, fitted risk slope, and nuisance effects. One simulated dataset cannot establish bias, coverage, or practical identification. Repeated simulation on the actual proposed design should evaluate bias, interval coverage and width, convergence, and decision accuracy, with Monte Carlo uncertainty. Include model-misspecification scenarios rather than requiring a predetermined bias sign.

5. **“Once daily” does not prove negligible incomplete repair (lines 259–260).** Use the same exposure evaluator when fitting and predicting. For 70 Gy in 35 Monday–Friday fractions and a four-hour monoexponential repair half-time, the exact quadratic sum is 143.5416351734 Gy². Relative to complete repair, this adds 1.1805450578 Gy BED at α/β = 3 Gy. This is a mathematical sensitivity example, not an empirical repair prior. Approximation adequacy must be assessed on candidate-minus-reference differences and the decision boundary, rather than on the absolute residual repair fraction alone.

6. **Identification must include risk slope and repair (lines 325–340).** For fixed repair, the within-family response includes both total-dose and quadratic-dose contrasts. Separate identification of the dose-response slope and its fractionation component requires sufficient independent information after accounting for nuisance terms. Estimating repair additionally requires sensitivity to repair in the full Jacobian. A fraction-size contrast in every individual trial is not mathematically necessary if compatible complementary contrasts across trials identify common parameters. Conversely, numerical rank alone does not show useful practical identification. Use profiles, joint posterior geometry, and actual-design recovery simulations. Weakly supported parameters should remain fixed named scenarios or be reported as prior-sensitive.

7. **Prior provenance and lognormal parameterization need correction (lines 307–323).** The verified Stuschke–Thames abstract reports a grade ≥2 late α/β estimate of 4.0 Gy with a 3.3–5.0 Gy interval at fixed dose-response steepness γ₅₀ = 5, and lower values at lower assumed steepness. It is conditional evidence, not a universal late-tissue distribution. Its underlying trial data cannot also supply independent likelihood information. The same overlap issue applies to CHART-derived repair parameters. A lognormal median of 3 Gy and central 95% limits of 1 and 10 Gy cannot hold simultaneously. The latter limits imply median √10 ≈ 3.1623 Gy, logarithmic mean log(√10), and logarithmic standard deviation log(10)/(2 × 1.959964). These would still be analyst assumptions rather than a validated empirical prior. Slope, baseline, heterogeneity, and repair priors need explicit scales and prior predictive assessment.

8. **Consequential injury checks require matched repair and causal caution (lines 286–305).** Equal fraction number and size do not imply equal repaired exposure when calendars differ. A same-dose timing comparison tests the direct late-injury model only after accounting for repair, co-treatment, endpoint, and population differences. An early-BED covariate is a structural sensitivity and may be highly collinear with duration and late exposure. Observed acute toxicity and delivered chemotherapy are post-randomization variables. Aggregate associations do not identify individual causal mediation, and adjusting for delivered treatment can alter the target effect or induce selection bias.

9. **Early infrastructure is reusable, but late extraction needs different safeguards.** `tools/early_tox/build_arms.py` defaults unspecified intraday spacing to six hours, so late extraction must distinguish reported intervals, minimum intervals, reconstructions, and assumptions. Its integer conversion can truncate noninteger values, which should be rejected for exact late counts. An arm-plus-endpoint key is insufficient when horizon, estimator, and population differ. The early identification script averages exposure over variants. In a nonlinear late-risk model, preserve strata or average variant-specific probabilities, rather than treating the risk at mean BED as the average risk. Carry fit checks into the final proposed model instead of relying solely on a simplified early identification fixture.

## Reproducible numerical work

`decision_sensitivity.py` independently implements the inspected formulas, loads current tumor point values and the early manifest, and writes `decision_sensitivity_independent.csv`. It was syntax checked and run. It reproduces the 69/9 default candidate fixtures.

`verify_app_engine.R` sources the actual project R functions and uses `refit_profile()`, `startup_profile()`, `load_early_fit()`, `fitted_early_params()`, and `v4_regimens()`. The latter is the engine used by the home page. It was parsed and run in R 4.5.1 with jsonlite 2.0.0 and digest 0.6.39. It writes `decision_sensitivity_R_summary.csv` and `decision_sensitivity_R_app_rows.csv`. The fitted early parameters were loaded through the actual validated loader: α/β 12.8683 Gy, time-loss rate 1.5538 Gy/day, onset 7 elapsed days, and repair half-time 3.2 hours. They were not reconstructed from marginal posterior summaries.

The standard reference uses 47 inclusive calendar days, corresponding to 46 elapsed days in the acute evaluator. The calculation holds all other application defaults fixed, including the −5/+5/+5-Gy tumor/early/late BED margins and the 0.05-Gy dose grid.

| Late α/β, Gy | Fowler combinations | Research-early combinations |
|---:|---:|---:|
| 1.00 | 55 | 9 |
| 1.50 | 65 | 9 |
| 1.58 | 66 | 9 |
| 1.59 | 67 | 9 |
| 1.61 | 68 | 9 |
| 1.62 | 69 | 9 |
| 2.00 | 69 | 9 |
| 2.50 | 69 | 9 |
| 3.00 | 69 | 9 |
| 4.00 | 69 | 9 |
| 5.00 | 69 | 9 |

These are deterministic candidate-list checks, not new fits, clinical validation, or posterior uncertainty calibration.

## Final consolidated-draft check

All eight numerical rows in the consolidated draft's sensitivity table (lines 187–196 at the reviewed hash) were programmatically matched against the corresponding R summary CSV cells, including both early modes. The 18 and five fraction-count statements were checked against the CSV. The exact 29 × 2.30-Gy threshold was recomputed. The four-hour repair example, lognormal median identities, and EQD2 numerical example were independently recalculated. All passed at the stated rounding.

Equation walk, in draft order:

1. **EQD2 conversion, line 81: PASS.** The denominator is 1 + 2 Gy/(α/β), giving 1.2 at α/β = 10 Gy. BED and EQD2 retain dose units. 0.63/1.2 = 0.525, reported as approximately 0.53. The warning about transforming joint draws before marginal summaries is appropriate.
2. **Complete-repair candidate-minus-reference BED, lines 200–204: PASS.** The total-dose difference and quadratic-dose difference divided by α/β both have dose units. At 35 × 2 Gy, both differences vanish. The reference quadratic dose sum is 35 × 2² = 140 Gy².
3. **Eligibility boundary, lines 206–210: PASS.** Rearranging the +5-Gy allowance gives the stated lower bound when total dose is below 75 Gy and the quadratic-dose difference is positive. The stated conditions are necessary for that direction of inequality. The threshold agrees with the executable candidate-list calculation.
4. **Repair exposure, lines 222–230: PASS.** The pair sum has the correct factor of two. For distinct delivery times and half-time tending to zero, Q tends to the sum of squared fraction doses. For half-time tending to infinity, Q tends to total dose squared. A common shift in all times leaves Q unchanged. The exponent is dimensionless, Q has squared-dose units, and D + Q/a has dose units. This assumes effectively instantaneous fraction delivery and monoexponential repair, as described by the schedule model.
5. **Binomial/logistic working model, lines 238–247: PASS.** Probabilities remain in (0,1), with a dimensionless BED contrast divided by 10 Gy. The slope is the log-odds increment per 10 Gy. Trial, arm, reference, count, denominator, baseline, slope, co-treatment, and arm-effect terms are defined. This is explicitly a working proposal rather than an already calibrated late model. Correct likelihood use remains conditional on the endpoint/observation rules immediately following it.
6. **Lognormal quantile statements, line 289: PASS.** Geometric symmetry gives median √(1 × 10) or √(1 × 9), respectively. Neither is claimed to be a literature-validated universal late prior.

The likelihood selection, distinction among uncertainty sources, family-level overlap exclusions, identification gates, conditional research-only integration, and the possibility of stopping at evidence synthesis address the substantive original-plan findings. No material mathematical, numerical-table, or stopping-rule error was identified in this final scoped review. Final wording and future fit criteria must remain tied to the selected endpoint and observation model. The plan does not manufacture calibrated uncertainty.

One material presentation correction was returned to the parent: prose lines 206, 222, and 245 use mathematical expressions outside math delimiters, including `(nd < 75\,\mathrm{Gy})`, `(d_i)`, `(\kappa)`, and `(\gamma)`. Replace these with properly delimited inline mathematics or Unicode Greek/subscripts. Plain parentheses do not enable math rendering. This correction does not change the verified equations or numerical results. The consolidated draft was not edited by this reviewer.

## Primary-source checks and limits

The following primary sources were consulted for the statistical/estimand assessment:

1. Stuschke M, Thames HD. Fractionation sensitivities and dose-control relations of head and neck carcinomas: analysis of the randomized hyperfractionation trials. Radiotherapy and Oncology. 1999;51(2):113–121. https://pubmed.ncbi.nlm.nih.gov/10435801/ and https://doi.org/10.1016/S0167-8140(99)00042-0. The conditional α/β estimate and assumed dose-response steepness were checked against the primary abstract.
2. Beitler JJ et al., primary report of RTOG 9003 final results. International Journal of Radiation Oncology, Biology, Physics. 2014;89(1):13–20. https://pmc.ncbi.nlm.nih.gov/articles/PMC4664465/ and https://doi.org/10.1016/j.ijrobp.2013.12.027. Landmark prevalence, worst late-grade records, and disease-free subsets were checked as distinct estimands.

The parent and clinical review stream own the complete reference/PDF archive and full clinical extraction-table verification. This methods stream did not refit the tumor or early models, assemble a complete late dataset, estimate a late posterior, validate new late risk thresholds, or establish real-world clinical safety. The final check did not independently rerun the other stream's tumor fit-provenance or live-browser checks.
