"""Read-only independent implementation of inspected app formulas; not app code."""
import csv, json, math
from pathlib import Path
import numpy as np

ROOT=Path(r'C:\Users\Igor\Desktop\Office\HNSCC_BED_calculator\Custom_BED_calculator_v45')
OUT=Path(__file__).parent
pv=json.loads((ROOT/'draws/refit_point_values.json').read_text())['values']
ep=json.loads((ROOT/'draws/early_fit_manifest.json').read_text())['point_values']
def sm(x):
    return x if 3*x>30 else math.log1p(math.exp(3*x))/3
def days(n):
    return np.array([7*(i//5)+i%5+1 for i in range(n)])
def Q(n,d,h):
    t=24*days(n)
    return d*d*np.exp(-math.log(2)*abs(t[:,None]-t[None,:])/h).sum()
def lq(n,d,a):
    return n*d*(1+d/a)
def di(n,d,T):
    p=pv['di']
    return lq(n,d,p['ab'])-p['lambda']*sm(T-p['Tk'])/p['alpha']-p['g']*T/p['alpha']
def dd(n,d,T):
    p=pv['dd']; K=lq(n,d,p['ab'])
    return K-p['lambda']*(-math.expm1(-p['alpha']*K/T))*sm(T-p['c_over_alpha']*T/K)/p['alpha']-p['g']*T/p['alpha']
def early(n,d,T,mode):
    if mode=='fowler':
        return lq(n,d,10)-math.log(2)/2.5/0.35*sm(T-1-7)
    return n*d+Q(n,d,3.2)/ep['ab_e']-ep['r_e']*max(0,T-1-7)
rows=[]
for mode in ['fowler','fitted']:
    ref=(di(35,2,47), dd(35,2,47), early(35,2,47,mode))
    for a in [1,1.5,1.58,1.59,2,2.5,3,4,5]:
        for n in range(5,31):
            T=int(days(n)[-1]); ds=np.round(np.arange(2.05,8.001,.05),6)
            tumor=[]; ec=[]; lc=[]; feasible=[]
            for d in ds:
                bdi,bdd=di(n,d,T),dd(n,d,T)
                goodt=(bdi>0 and ref[0]>0 and bdi-ref[0]>=-5-1e-9) or (bdd>0 and ref[1]>0 and bdd-ref[1]>=-5-1e-9)
                be=early(n,d,T,mode)
                goode=(mode=='fitted' or be>0) and be-ref[2]<=5+1e-9
                goodl=lq(n,d,a)-lq(35,2,a)<=5+1e-9
                if goodt: tumor.append(d)
                if goode: ec.append(d)
                if goodl: lc.append(d)
                if goodt and goode and goodl: feasible.append(d)
            rows.append(dict(mode=mode,a=a,n=n,T=T,tumor_min=min(tumor) if tumor else None,
                early_max=max(ec) if ec else None, late_max=max(lc) if lc else None,
                n_feasible=len(feasible), doses=';'.join(f'{x:.2f}' for x in feasible)))
with (OUT/'decision_sensitivity_independent.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for mode in ['fowler','fitted']:
    for a in [1,1.5,1.58,1.59,2,2.5,3,4,5]:
        rr=[r for r in rows if r['mode']==mode and r['a']==a]
        print(mode,a,sum(r['n_feasible'] for r in rr),[r['n'] for r in rr if r['n_feasible']])
assert sum(r['n_feasible'] for r in rows if r['mode']=='fowler' and r['a']==3)==69
assert sum(r['n_feasible'] for r in rows if r['mode']=='fitted' and r['a']==3)==9
assert abs(Q(35,2,3.2)/10+70-84.1242591)<1e-6
